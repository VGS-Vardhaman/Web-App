from flask import Flask, render_template, request, redirect, url_for, flash
import tensorflow as tf
import numpy as np
from PIL import Image, UnidentifiedImageError
import logging

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Needed for flashing messages

logging.basicConfig(level=logging.DEBUG)

# Load pre-trained model
model = tf.keras.models.load_model('plant_identification_model.h5')

# Plant name and properties mapping
label_mapping = {
    0: 'Alpinia Galanga (Rasna) Description Alpinia Galanga, or Rasna, is valued for its anti-inflammatory properties, aiding digestion, and serving as an analgesic. Its medicinal profile includes anti-microbial benefits, making it a versatile herb in traditional medicine practices',
    1: 'Amaranthus Viridis (Arive-Dantu) Description Arive-Dantu, is known for its medicinal properties such as anti-inflammatory effects, aiding digestion, and promoting cardiovascular health. Rich in antioxidants and vitamins, it supports immune function and may help in managing conditions like diabetes and hypertension.',
    2: 'Artocarpus Heterophyllus (Jackfruit) Description Jackfruit contains functional compounds that have capability to reduce various diseases such as high blood pressure, heart diseases, strokes, and bone loss. It is also capable of improving muscle and nerve function, reducing homocysteine levels in the blood.',
    # Add other mappings as necessary
    3: 'Azadirachta Indica (Neem) Description Prevalent in traditional remedies from a long time, Neem is considered as a boon for Mankind. It helps to cure many skin diseases such as Acne, fungal infections, dandruff, leprosy, and also nourishes and detoxifies the skin. It also boosts your immunity and act as an Insect and Mosquito Repellent. It helps to reduce joint paint as well and prevents Gastrointestinal Diseases',
    4: 'Basella Alba (Basale) Description Basella alba is reported to improve testosterone levels in males, thus boosting libido. Decoction of the leaves is recommended as a safe laxative in pregnant women and children. Externally, the mucilaginous leaf is crushed and applied in urticaria, burns and scalds.',
    5: 'Brassica Juncea (Indian Mustard) Description Mustard greens are a rich source of vitamins and minerals your body needs to stay healthy. One serving contains almost half of your daily vitamin C needs. Vitamin C contributes to your body’s immune system defenses, so it’s important to get enough of it throughout your day.',
    6: 'Carissa Carandas (Karanda) Description Karanda is used for to treat acidity, indigestion, fresh and infected wounds, skin diseases, urinary disorders and diabetic ulcer, as well as biliousness, stomach pain, constipation, anemia, skin conditions, anorexia and insanity.',
    7: 'Citrus Limon (Lemon) Description Lemons are an excellent source of Vitamin C and fiber, and therefore, it lowers the risk factors leading to heart diseases. Lemons are also known to prevent Kidney Stones as they have Citric acid that helps in preventing Kidney Stones. Lemon, with Vitamin C and citric acid helps in the absorption of iron.',
    8: 'Ficus Auriculata (Roxburgh fig) Description It is used  in traditional medicine to treat various ailments such as gastrointestinal (colic, indigestion, loss of appetite, and diarrhea), respiratory (sore throats, coughs, and bronchial problems), and cardiovascular disorders and as anti-inflammatory and antispasmodic remedy.',
    9: 'Ficus Religiosa (Peepal Tree) Description The leaf juice of the peepal tree may be helpful for cough, asthma, diarrhoea, ear pain, toothache, haematuria (blood in urine), migraine, scabies, eye troubles, and gastric problems. The stem bark of the peepal tree might help with paralysis, gonorrhoea, bone fractures, diarrhoea, and diabetes.',
    10: 'Hibiscus Rosa-sinensis (Hibiscus) Description  Hibiscus is used for treating loss of appetite, colds, heart and nerve diseases, upper respiratory tract pain and swelling (inflammation), fluid retention, stomach irritation, and disorders of circulation; for dissolving phlegm; as a gentle laxative; and as a diuretic to increase urine output',
    11: 'Jasminum (Jasmine) Description Jasmine is used in the curing of liver diseases, such as hepatits, and in abdominal pain caused due to intense diarrhea, or dysentery. The smell of Jasmine flowers can be used to improve mood, reduce stress levels, and also to reduce food cravings. Jasmine can also be used to help in fighting skin diseases and speed up the process of wound healing.',
    12: 'Mangifera Indica (Mango) Description  Known as King of Fruits by many, Mango is also packed with many medicinal properties. Mangoes have various Vitamins, such as Vitamin C, K, A, and minerals such as Potassium and Magnesium. Mangoes are also rich in anitoxidants, which can reduce the chances of Cancer. Mangoes are also known to promote digestive health and heart health too .',
    13: 'Mentha (Mint) Description  Mint is used usually in our daily lives to keep bad mouth odour at bay, but besides that, this plant also help in a variety of other functions such as relieving Indigestion, and upset stomach, and can also improve Irritable Bowel Syndrome (IBS). Mint is also full of nutrients such as Vitamin A, Iron, Manganese, Folate and Fiber.',
    14: 'Moringa Oleifera (Drumstick) Description The fresh leaves of the drumstick tree are used in anaemia as they are rich in iron which may help improve haemoglobin levels. Drumstick leaves due to a high nutritional content may help in malnutrition. Drumstick leaves may help manage asthma by relaxing respiratory muscles and improving breathing.',
    15: 'Muntingia Calabura (Jamaica Cherry-Gasagase) Description The Jamaican cherry plant, especially its leaves, is known for its anti-nociceptive property that blocks your nerves from experiencing pain. Its leaves also consist of antioxidants like vitamin C and flavonoids, which contribute to the pain-blocking function.',
    16: 'Murraya Koenigii (Curry) Description Curry leaves oil is rich in vitamins and calcium and may be used for strengthening the bones, might reduce the possibilities of osteoporosis (weak bones) and managing calcium deficiency. The branches of Murraya koenigii are called DATUM . They may be used to strengthen the gums and clean teeth.',
    17: 'Nerium Oleander (Oleander) Description Oleander seeds and leaves are used to make medicine. Oleander is used for heart conditions, asthma, epilepsy, cancer, painful menstrual periods, leprosy, malaria, ringworm, indigestion, and venereal disease; and to cause abortions.',
    18: 'Nyctanthes Arbor-tristis (Parijata) Description Parijat leaves has been used to treat a different kind of fevers, cough, arthritis, worm infestation, etc. The leaves juice is bitter and works as a tonic. The kadha or decoction is excellent for arthritis, constipation, worm infestation.',
    19: 'Ocimum Tenuiflorum (Tulsi) Description Tulsi plant has the potential to cure a lot of ailments, and is used a lot in traditional remedies. Tulsi can help cure fever, to treat skin problems like acne, blackheads and premature ageing, to treat insect bites. Tulsi is also used to treat heart disease and fever, and respiratory problems.',
    20: 'Piper Betle (Betel) Description The leaves of Betel possess immense therapeutic potential, and are often used in helping to cure mood swings and even depression. They are also quite an effective way to improve digestive health as they effectively neutralise pH imbalances in the stomach. The leaves are also full of many anti-microbial agents that combat the bacteria in your mouth.',
    21: 'Plectranthus Amboinicus (Mexican Mint) Description  It has a plethora of health benefits that may include its ability to improve skin, detoxify the body, defend against cough and cold, ease arthritis pain, relieve stress, and optimize digestion.',
    22: 'Pongamia Pinnata (Indian Beech) Description Beech leaves contain a substance effective for ulcers and reducing the inflammation of dysentery. Leaves are also soothing to the nerves and stomach. A tonic can be made from beech leaves that cleans the digestive system and stimulates the appetite.',
    23: 'Psidium Guajava (Guava) Description The fruit is commonly eaten fresh or made into beverages, jams, and other foods. Various parts of the plant, including the leaf and the fruit, are used as medicine. People use guava leaf for stomach and intestinal conditions, pain, diabetes, and wound healing. The fruit is used for high blood pressure.',
    24: 'Punica Granatum (Pomegranate) Description Pomegranate has a variety of medical benefits. It is rich in antioxidants, which reduce inflation, protect cells from damage and eventually lower the chances of Cancer. It is also a great source of Vitamin C and an immunity booster. Pomegranate has also shown to stall the progress of Alzheimer disease and protect memory',
    25: 'Santalum Album (Sandalwood) Description Sandalwood leaves are utilized in traditional medicine for their anti-inflammatory properties, aiding in the treatment of skin conditions like acne and eczema. They are also known for their antimicrobial effects, assisting in wound healing and providing relief from minor cuts and insect bites. Additionally, sandalwood leaf extracts have been used to alleviate respiratory issues and promote oral hygiene.',
    26: 'Syzygium Cumini (Jamun) Description The leaves of black plum or jamun tree have antibacterial properties and are used to maintain oral health. The astringent characteristics of the leaves are considered effective for throat problems. A solution made using the bark of a jamun tree helps treat mouth ulcers credited to its highly acidic nature.',
    27: 'Syzygium Jambos (Rose Apple) Description  Rose apple leaves are valued for their medicinal properties, known to possess anti-diabetic effects by helping regulate blood sugar levels. They also exhibit antimicrobial properties, aiding in the treatment of various infections, and are traditionally used for their anti-inflammatory benefits, providing relief from conditions such as arthritis and fever.',
    28: 'Tabernaemontana Divaricata (Crape Jasmine) Description  It is used to treat various diseases like rheumatic pain, headache, piles, inflammation, eye infections, abdominal tumors, strangury, arthralgia, epilepsy, fever, asthma, fractures, leprosy, paralysis, mania, oedema, rabies, skin diseases, urinary disorders, toothache, ulceration and vomiting.',
    29: 'Trigonella Foenum-graecum (Fenugreek) Description Fenugreek leaves are eaten in India as a vegetable. Fenugreek is taken by mouth for digestive problems such as loss of appetite, upset stomach, constipation, inflammation of the stomach (gastritis). Fenugreek is also used for diabetes, painful menstruation, polycystic ovary syndrome, and obesity.',
}


def preprocess_image(image):
    try:
        image = image.resize((224, 224))
        logging.debug(f"Image resized to: {image.size}")

        image_array = np.array(image)
        logging.debug(f"Image array shape: {image_array.shape}")

        image_array = image_array / 255.0  # Normalize pixel values
        image_array = np.expand_dims(image_array, axis=0)
        logging.debug(f"Preprocessed image array shape: {image_array.shape}")

        return image_array
    except Exception as e:
        flash(f"Error preprocessing image: {e}", 'error')
        logging.error(f"Error preprocessing image: {e}")
        return None


def process_predictions(predictions):
    try:
        logging.debug(f"Predictions: {predictions}")

        predicted_label_index = np.argmax(predictions)
        predicted_label = label_mapping.get(predicted_label_index, 'Unknown')
        result = predicted_label.split("Description")
        confidence = predictions[0][predicted_label_index]

        logging.debug(f"Predicted label: {result[0]}, Description: {result[1]}, Confidence: {confidence}")

        return result[0], result[1]
    except Exception as e:
        flash(f"Error processing predictions: {e}", 'error')
        logging.error(f"Error processing predictions: {e}")
        return 'Unknown', 'Description not available', 0.0


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/classify', methods=['POST'])
def classify():
    try:
        uploaded_image = request.files['image']

        if uploaded_image.filename == '':
            flash("No image file selected", 'error')
            return redirect(url_for('index'))

        try:
            image = Image.open(uploaded_image)
        except UnidentifiedImageError:
            flash("The uploaded file is not a valid image", 'error')
            return redirect(url_for('index'))

        preprocessed_image = preprocess_image(image)

        if preprocessed_image is not None:
            predictions = model.predict(preprocessed_image)
            result = process_predictions(predictions)
            return render_template('result.html', result1=result[0], result2=result[1])
        else:

            flash("Error preprocessing image", 'error')
            return redirect(url_for('index'))
    except Exception as e:
        flash(f"Error classifying image: {e}", 'error')
        logging.error(f"Error classifying image: {e}")
        return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
