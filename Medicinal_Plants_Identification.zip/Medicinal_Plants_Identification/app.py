from flask import Flask, render_template, request, redirect, url_for , flash
import tensorflow as tf
import numpy as np
from PIL import Image

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'


#to load pretrain model
model = tf.keras.models.load_model('plant_identification_model.h5')

#plant name and properties
label_mapping = {0: 'Alpinia Galanga (Rasna)  Description   Alpinia Galanga, or Rasna, is valued for its anti-inflammatory properties, aiding digestion, and serving as an analgesic. Its medicinal profile includes anti-microbial benefits, making it a versatile herb in traditional medicine practices' ,
                 1: 'Amaranthus Viridis (Arive-Dantu) Description Arive-Dantu, is known for its medicinal properties such as anti-inflammatory effects, aiding digestion, and promoting cardiovascular health. Rich in antioxidants and vitamins, it supports immune function and may help in managing conditions like diabetes and hypertension. ',
                 2: 'Artocarpus Heterophyllus (Jackfruit) Description Jackfruit contains functional compounds that have capability to reduce various diseases such as high blood pressure, heart diseases, strokes, and bone loss. It is also capable of improving muscle and nerve function, reducing homocysteine levels in the blood. ' ,
                 3: 'Azadirachta Indica (Neem)  Description Prevalent in traditional remedies from a long time, Neem is considered as a boon for Mankind. It helps to cure many skin diseases such as Acne, fungal infections, dandruff, leprosy, and also nourishes and detoxifies the skin. It also boosts your immunity and act as an Insect and Mosquito Repellent. It helps to reduce joint paint as well and prevents Gastrointestinal Diseases ',
                 4: 'Basella Alba (Basale) Description Basella alba is reported to improve testosterone levels in males, thus boosting libido. Decoction of the leaves is recommended as a safe laxative in pregnant women and children. Externally, the mucilaginous leaf is crushed and applied in urticaria, burns and scalds.',
                 5: 'Brassica Juncea (Indian Mustard) Description Mustard greens are a rich source of vitamins and minerals your body needs to stay healthy. One serving contains almost half of your daily vitamin C needs. Vitamin C contributes to your body’s immune system defenses, so it’s important to get enough of it throughout your day. ',
                 6: 'Carissa Carandas (Karanda) Description Karanda is used for  to treat acidity, indigestion, fresh and infected wounds, skin diseases, urinary disorders and diabetic ulcer, as well as biliousness, stomach pain, constipation, anemia, skin conditions, anorexia and insanity.',
                 7: 'Citrus Limon (Lemon) Description  Lemons are an excellent source of Vitamin C and fiber, and therefore, it lowers the risk factors leading to heart diseases. Lemons are also known to prevent Kidney Stones as they have Citric acid that helps in preventing Kidney Stones. Lemon, with Vitamin C and citric acid helps in the absorption of iron .',
                 8: 'Ficus Auriculata (Roxburgh fig)',
                 9: 'Ficus Religiosa (Peepal Tree)',
                 10: 'Hibiscus Rosa-sinensis',
                 11: 'Jasminum (Jasmine)',
                 12: 'Mangifera Indica (Mango) Description ',
                 13: 'Mentha (Mint)',
                 14: 'Moringa Oleifera (Drumstick)',
                 15: 'Muntingia Calabura (Jamaica Cherry-Gasagase)',
                 16: 'Murraya Koenigii (Curry) Description ',
                 17: 'Nerium Oleander (Oleander)',
                 18: 'Nyctanthes Arbor-tristis (Parijata)',
                 19: 'Ocimum Tenuiflorum (Tulsi)',
                 20: 'Piper Betle (Betel) Description ',
                 21: 'Plectranthus Amboinicus (Mexican Mint)',
                 22: 'Pongamia Pinnata (Indian Beech)',
                 23: 'Psidium Guajava (Guava)',
                 24: 'Punica Granatum (Pomegranate)',
                 25: 'Santalum Album (Sandalwood)',
                 26: 'Syzygium Cumini (Jamun)',
                 27: 'Syzygium Jambos (Rose Apple)',
                 28: 'Tabernaemontana Divaricata (Crape Jasmine)',
                 29: 'Trigonella Foenum-graecum (Fenugreek)'}


def preprocess_image(image):

    try:
        #resize image to match input
        image = image.resize((224, 224))

    #Convert the image to an array and preprocess
        image_array = np.array(image)
        image_array = image_array / 255.0  # Normalize pixel values
        image_array = np.expand_dims(image_array, axis=0)

        return image_array
    except Exception as e:
        flash(f"Error preprocessing image: {e}", 'error')
        return None


# def process_predictions(predictions):
#     # Assuming you have a label_mapping dictionary defined
#     predicted_label_index = np.argmax(predictions)
#     predicted_label = label_mapping.get(predicted_label_index, 'Unknown')
#     confidence = predictions[0][predicted_label_index]
#
#     return f'Predicted Label: {predicted_label}, Confidence: {confidence:.2f}'
def process_predictions(predictions):
    try:
        predicted_label_index = np.argmax(predictions)
        predicted_label = label_mapping.get(predicted_label_index, 'Unknown')
        result = predicted_label.split("Description")
        confidence = predictions[0][predicted_label_index]

        print(result[0],result[1] , confidence)
        return result[0] , result[1]

    except Exception as e:
        flash(f"Error processing predictions: {e}", 'error')
        return 'Unknown', 'Description not available', 0.0
#  str(confidence)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/classify', methods=['POST'])
def classify():
    #Get the uploaded image file from the form
    try:
        uploaded_image = request.files['image']

        if uploaded_image.filename == '':
            flash("No image file selected", 'error')
            return redirect(url_for('index'))
        # Open and preprocess the image
        image = Image.open(uploaded_image)
        preprocessed_image = preprocess_image(image)

        # Make predictions using your model
        if preprocessed_image is not None:
            predictions = model.predict(preprocessed_image)

            # Process the predictions and return the result
            result = process_predictions(predictions)
            # return render_template('result.html', result1=result[0] , result2=result[1] ,confidence = result[2]  )
            return render_template('result.html', result1=result[0], result2=result[1])
        else:
            flash("Error preprocessing image", 'error')
            return redirect(url_for('index'))
    except Exception as e:
        flash(f"Error classifying image: {e}", 'error')
        return redirect(url_for('index'))




if __name__ == '__main__':
    app.run(debug=True)